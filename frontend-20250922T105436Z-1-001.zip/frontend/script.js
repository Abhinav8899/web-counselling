/* =========================
   SAFETY NET BOOTSTRAP
   (Paste this at the VERY TOP of script.js)
   ========================= */
(function () {
  // 1) Make all scroll-animated sections visible as a fallback
  try {
    var nodes = document.querySelectorAll('.animate-on-scroll');
    nodes.forEach(function (el) {
      el.classList.add('is-visible');       // makes them visible even if observer fails
      el.style.opacity = '1';               // hard fallback in case CSS class name changes
      el.style.transform = 'none';
    });
  } catch (e) {
    console.warn('SafetyNet: animate-on-scroll fallback failed:', e);
  }

  // 2) Hide full-screen overlays that can block the UI
  try {
    ['onboarding-modal', 'otp-modal', 'overlay'].forEach(function (id) {
      var el = document.getElementById(id);
      if (el) {
        el.style.display = 'none';
        el.setAttribute('aria-hidden', 'true');
      }
    });
  } catch (e) {
    console.warn('SafetyNet: modal/overlay hide failed:', e);
  }

  // 3) Ensure registration status container exists to avoid runtime errors later
  try {
    var regForm = document.getElementById('register-form');
    if (regForm && !document.getElementById('registration-message')) {
      var status = document.createElement('div');
      status.id = 'registration-message';
      status.className = 'form-status';
      status.style.marginTop = '10px';
      regForm.insertAdjacentElement('afterend', status);
    }
  } catch (e) {
    console.warn('SafetyNet: registration-message creation failed:', e);
  }
})();

// =============================
// Configuration
// =============================
const API_BASE = "http://localhost:5000";

// =============================
// Utility function for error handling
// =============================
function showError(container, message) {
    if (container) {
        container.innerHTML = `<div class="error-message" style="color:red; font-weight:bold; padding:10px;">${message}</div>`;
    }
}




/* =========================
   ERROR-AWARE FETCH WRAPPERS
   ========================= */

// College loader with error message
async function loadCollegesSafe() {
  const container = document.getElementById('college-list');
  if (!container) return;

  try {
    const res = await fetch('http://localhost:5000/api/colleges');
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const colleges = await res.json();

    if (!Array.isArray(colleges) || colleges.length === 0) {
      container.innerHTML = `<p style="color:red;">No colleges found.</p>`;
      return;
    }

    container.innerHTML = colleges.map(college => `
      <div class="college-card">
        <h3>${college.name}</h3>
        <p>${college.location}</p>
        <p>Established: ${college.est_year || 'N/A'}</p>
        <a href="${college.website}" target="_blank">Visit Website</a>
      </div>
    `).join('');
  } catch (err) {
    console.error("Colleges fetch failed:", err);
    container.innerHTML = `<p style="color:red;">❌ Failed to load colleges from backend.</p>`;
  }
}

// Predictor with error message
function initPredictorSafe() {
  const form = document.getElementById('predictor-form');
  const result = document.getElementById('predictor-results');
  if (!form || !result) return;

  form.addEventListener('submit', async e => {
    e.preventDefault();
    result.innerHTML = "Predicting...";

    const rank = document.getElementById('rank').value;
    const category = document.getElementById('category').value;

    try {
      const res = await fetch('http://localhost:5000/api/predict', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rank, category })
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      result.innerHTML = `<p>${data.message || "Prediction complete."}</p>`;
    } catch (err) {
      console.error("Predictor fetch failed:", err);
      result.innerHTML = `<p style="color:red;">❌ Failed to get prediction from backend.</p>`;
    }
  });
}

// =============================
// Registration (with validation)
// =============================
function initRegistration() {
  const regForm = document.getElementById('register-form');
  const messageContainer = document.getElementById('registration-message');

  if (!regForm) return;

  regForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    // Collect values
    const name = document.getElementById('reg-name').value.trim();
    const contact = document.getElementById('reg-contact').value.trim();
    const email = document.getElementById('reg-email').value.trim();
    const courseField = document.getElementById('reg-course');
    const course = courseField.value;

    // -------------------------------
    // Client-side Validation
    // -------------------------------
    if (!/^[A-Za-z ]{3,}$/.test(name)) {
  messageContainer.innerHTML = `<p style="color:red;">❌ Full name must be at least 3 letters and contain only alphabets/spaces.</p>`;
  return;
}

    

    if (!/^[0-9]{10}$/.test(contact)) {
      messageContainer.innerHTML = `<p style="color:red;">⚠️ Enter a valid 10-digit mobile number.</p>`;
      return;
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      messageContainer.innerHTML = `<p style="color:red;">⚠️ Enter a valid email address.</p>`;
      return;
    }
    if (!course) {
  const errorEl = courseField.closest('.form-group').querySelector('.error-message');
  errorEl.textContent = "Please select a course.";
  errorEl.style.display = "block";
  return;
} else {
  const errorEl = courseField.closest('.form-group').querySelector('.error-message');
  errorEl.textContent = "";
  errorEl.style.display = "none";
}



    // Passed validation → Submit to backend
    messageContainer.innerHTML = "Submitting...";

        try {
      const res = await fetch(`${API_BASE}/api/registrations`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fullName: name, phone: contact, email, course })
      });

      const result = await res.json();

      if (!res.ok) {
        // Show backend-provided error instead of generic one
        messageContainer.innerHTML = `<p style="color:red;">❌ ${result.error || "Registration failed."}</p>`;
        return;
      }

      // Success
      messageContainer.innerHTML = `<p style="color:green;">${result.message || "✅ Registration successful."}</p>`;
      regForm.reset();
    } catch (err) {
      console.error("Network error while registering:", err);
      messageContainer.innerHTML = `<p style="color:red;">❌ Could not connect to backend. Check if server is running.</p>`;
    }

  });
}



/* =========================
   BOOTSTRAP INIT
   ========================= */
document.addEventListener('DOMContentLoaded', () => {
  loadCollegesSafe();
  initPredictorSafe();
  initRegistration();

  // ------------------ Hardcoded Dummy Data Fallbacks ------------------

// 1. Stats Section
function loadDummyStats() {
  const stats = {
    studentsCounselled: 1200,
    successRate: 92,
    partnerInstitutions: 35,
    yearsExperience: 10
  };

  document.querySelector("#studentsCounselled").textContent = stats.studentsCounselled;
  document.querySelector("#successRate").textContent = stats.successRate + "%";
  document.querySelector("#partnerInstitutions").textContent = stats.partnerInstitutions;
  document.querySelector("#yearsExperience").textContent = stats.yearsExperience;
}





// Run the dummy loaders
loadDummyStats();


});
// ---------------- Stats Counter Animation ----------------
function animateCounters() {
  const counters = document.querySelectorAll(".counter");
  const speed = 200; // smaller = faster

  counters.forEach(counter => {
    const updateCount = () => {
      const target = +counter.getAttribute("data-target");
      const count = +counter.innerText;

      const increment = Math.ceil(target / speed);

      if (count < target) {
        counter.innerText = count + increment;
        setTimeout(updateCount, 20);
      } else {
        counter.innerText = target; // final value
      }
    };

    updateCount();
  });
}

// Run when page loads
animateCounters();

// ---------------- Testimonials Section ----------------
function loadTestimonials() {
  const testimonials = [
    { name: "Priya Verma", text: "Thanks to CampusCircuit, I got into my dream college!" },
    { name: "Rahul Kumar", text: "The guidance was spot on. Really grateful for the mentorship." },
    { name: "Anjali Patel", text: "Smooth process and helpful team throughout my admission journey." }
  ];

  const container = document.querySelector(".testimonial-grid");
  if (!container) return;

  container.innerHTML = testimonials.map(t => `
    <div class="testimonial-card">
      <p>"${t.text}"</p>
      <h4>- ${t.name}</h4>
    </div>
  `).join("");
}

loadTestimonials();


// ---------------- FAQ Section (Hardcoded with Answers + Accordion) ----------------
// This builds FAQ with expandable answers.
// To add/remove FAQ, just update the 'faqs' array.
function loadFAQ() {
  const faqs = [
    {
      q: "How do I register on CampusCircuit?",
      a: "Click on the registration form in the 'Ready to Start?' section, fill your details, and submit. You will receive confirmation after successful submission."
    },
    {
      q: "Is there a counselling fee?",
      a: "Our basic counselling is completely free. For premium, one-on-one guidance packages, additional fees may apply."
    },
    {
      q: "How does the college predictor work?",
      a: "It uses your rank and category to suggest eligible colleges based on past admission trends."
    },
    {
      q: "Can I get details about specific colleges?",
      a: "Yes, use the 'College Information' section to search and filter colleges by name, location, and view their details."
    },
    {
      q: "Who are the mentors?",
      a: "Our mentors are experienced counsellors and professionals who specialize in career guidance, engineering, and medical admissions."
    }
  ];

  const container = document.querySelector(".faq-container");
  if (!container) return;

  // Build FAQ HTML
  container.innerHTML = faqs.map(f => `
    <div class="faq-item">
      <button class="faq-question">${f.q}</button>
      <div class="faq-answer">
        <p>${f.a}</p>
      </div>
    </div>
  `).join("");

  // Add accordion functionality
  const questions = container.querySelectorAll(".faq-question");
  questions.forEach((btn) => {
    btn.addEventListener("click", () => {
      const answer = btn.nextElementSibling;

      // Close all other answers before opening new one
      container.querySelectorAll(".faq-answer").forEach((a) => {
        if (a !== answer) a.style.maxHeight = null;
      });

      // Toggle clicked one
      if (answer.style.maxHeight) {
        answer.style.maxHeight = null; // collapse
      } else {
        answer.style.maxHeight = answer.scrollHeight + "px"; // expand
      }
    });
  });
}

// Run FAQ loader
loadFAQ();
// =============================
// Mentors Section (Hardcoded Data)
// =============================
function loadMentors() {
  const mentors = [
    { name: "Dr. Meera Sharma", expertise: "Career Counseling", image: "images/mentor1.jpg" },
    { name: "Prof. Rajesh Kumar", expertise: "Engineering Admissions", image: "images/mentor2.jpg" },
    { name: "Ms. Neha Verma", expertise: "Medical Guidance", image: "images/mentor3.jpg" }
  ];

  const container = document.querySelector('.expert-grid'); // ✅ correct selector
  if (!container) return;

  container.innerHTML = mentors.map(m => `
    <div class="mentor-card">
      <img src="${m.image}" alt="${m.name}" class="mentor-photo">
      <h4>${m.name}</h4>
      <p>${m.expertise}</p>
    </div>
  `).join('');
}

// Call it when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
  loadMentors();
});





