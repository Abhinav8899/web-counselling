const express = require('express');
const router = express.Router();
const Registration = require('../models/Registration');

// ================================
// POST /api/registrations
// Create a new registration
// ================================
router.post('/', async (req, res, next) => {
  try {
    const { fullName, phone, email, course } = req.body;

    // ---- Basic Validation ----
    if (!fullName || fullName.trim().length < 3) {
      return res.status(400).json({ error: 'Full name must be at least 3 characters.' });
    }

    if (!/^\d{10}$/.test(String(phone))) {
      return res.status(400).json({ error: 'Phone must be a 10-digit number.' });
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email))) {
      return res.status(400).json({ error: 'Invalid email address.' });
    }

    if (!['BTech', 'MTech', 'BS'].includes(course)) {
      return res.status(400).json({ error: 'Please select a valid course.' });
    }

    // ---- Save Registration ----
    const doc = await Registration.create({ fullName, phone, email, course });
    res.status(201).json({
      message: '✅ Registration saved successfully.',
      id: doc._id
    });
  } catch (err) {
    next(err);
  }
});

// ================================
// GET /api/registrations
// Fetch all registrations OR filter by course
// Example: /api/registrations?course=BTech
// ================================
router.get('/', async (req, res, next) => {
  try {
    const { course } = req.query;
    const filter = course ? { course } : {};
    const list = await Registration.find(filter).sort({ createdAt: -1 });
    res.json(list);
  } catch (err) {
    next(err);
  }
});

module.exports = router;
