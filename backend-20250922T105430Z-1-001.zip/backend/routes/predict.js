// routes/predict.js
const express = require('express');
const router = express.Router();
const predictCtrl = require('../controllers/predictController');

// POST /api/predict
router.post('/', predictCtrl.predict);

module.exports = router;
