// routes/colleges.js
const express = require('express');
const router = express.Router();
const collegeCtrl = require('../controllers/collegeController');
const auth = require('../middleware/auth');

// Public routes
router.get('/', collegeCtrl.list);
router.get('/:id', collegeCtrl.getById);

// Protected routes (require JWT)
router.post('/', auth.verify, collegeCtrl.create);
router.put('/:id', auth.verify, collegeCtrl.update);
router.delete('/:id', auth.verify, collegeCtrl.remove);

module.exports = router;
