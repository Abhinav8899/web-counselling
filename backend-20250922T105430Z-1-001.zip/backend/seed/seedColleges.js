// seed/seedColleges.js
require('dotenv').config();
const connectDB = require('../config/db');
const College = require('../models/College');

const sampleColleges = [
  {
    name: "National Tech University",
    location: "Delhi",
    est_year: 1963,
    accreditations: ["NAAC A++", "NBA Accredited"],
    image: "",
    gallery: [],
    rating: 4.8,
    fees: "₹1,50,000/year",
    website: "https://www.ntu.ac.in",
    description: "A premier institution offering engineering and sciences.",
    student_faculty_ratio: "15:1",
    campus_size: "300 acres",
    categoryCutoffs: { General: 3000, OBC: 5000, SC: 8000, ST: 10000 }
  },
  {
    name: "Metro Institute of Technology",
    location: "Mumbai",
    est_year: 1989,
    accreditations: ["NAAC A"],
    rating: 4.4,
    fees: "₹1,20,000/year",
    website: "https://www.mit.ac.in",
    description: "Strong industry ties and placement support.",
    categoryCutoffs: { General: 6000, OBC: 9000, SC: 15000 }
  }
];

async function run() {
  try {
    // Connect to MongoDB using .env value
    await connectDB();

    // Clear old data
    await College.deleteMany({});

    // Insert sample data
    await College.insertMany(sampleColleges);

    console.log("✅ Seed data inserted");
    process.exit(0);
  } catch (err) {
    console.error("❌ Error seeding data:", err);
    process.exit(1);
  }
}

run();
