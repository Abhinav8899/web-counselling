// models/College.js
const mongoose = require('mongoose');

const collegeSchema = new mongoose.Schema({
  name: { type: String, required: true, index: true },
  location: String,
  est_year: Number,
  accreditations: [String],
  image: String,
  gallery: [String],
  rating: Number,
  fees: String,
  website: String,
  description: String,
  student_faculty_ratio: String,
  campus_size: String,
  categoryCutoffs: {
    General: Number,
    OBC: Number,
    SC: Number,
    ST: Number
  }
}, { timestamps: true });

module.exports = mongoose.model('College', collegeSchema);
