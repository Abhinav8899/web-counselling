const mongoose = require('mongoose');

const registrationSchema = new mongoose.Schema({
  fullName: { type: String, required: true, trim: true },
  phone: { type: String, required: true, trim: true },
  email: { type: String, required: true, trim: true },
  course: { 
    type: String, 
    required: true, 
    enum: ['BTech', 'MTech', 'BS'] // only allowed values
  }
}, { timestamps: true });

module.exports = mongoose.model('Registration', registrationSchema);
