// controllers/predictController.js
const College = require('../models/College');

exports.predict = async (req, res, next) => {
  try {
    const { rank, category } = req.body;
    if (!rank || !category)
      return res.status(400).json({ error: 'Rank and category are required' });

    const colleges = await College.find({ [`categoryCutoffs.${category}`]: { $exists: true } }).lean();

    const results = colleges.map(c => {
      const cutoff = c.categoryCutoffs?.[category] ?? null;
      let chance = 'Low';
      if (cutoff && rank <= cutoff) {
        chance = rank > Math.floor(cutoff * 0.9) ? 'Close' : 'High';
      }
      return { college: c, cutoff, chance };
    })
    .filter(item => item.chance !== 'Low')
    .sort((a, b) => (a.cutoff || 0) - (b.cutoff || 0));

    res.json({ results });
  } catch (err) {
    next(err);
  }
};
