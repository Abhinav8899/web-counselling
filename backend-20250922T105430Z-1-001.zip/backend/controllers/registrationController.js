// controllers/registrationController.js
const Registration = require('../models/Registration');

exports.create = async (req, res, next) => {
  try {
    const reg = await Registration.create(req.body);
    res.status(201).json({ message: 'Registration received', id: reg._id });
  } catch (err) {
    next(err);
  }
};

exports.list = async (req, res, next) => {
  try {
    const regs = await Registration.find().sort({ createdAt: -1 }).limit(500);
    res.json(regs);
  } catch (err) {
    next(err);
  }
};
