require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const connectDB = require('./config/db');

// Routers
const collegesRouter = require('./routes/colleges');
const predictRouter = require('./routes/predict');
const regsRouter = require('./routes/registrations');
const authRouter = require('./routes/auth');

const app = express();

// Middleware
app.use(helmet());
app.use(cors());
app.use(express.json());
app.use(morgan('dev'));

// Connect to DB
connectDB(); // No arguments needed now

// Test route
app.get('/', (req, res) => res.json({ message: 'CampusCircuit Backend Running' }));

// API routes
app.use('/api/auth', authRouter);
app.use('/api/colleges', collegesRouter);
app.use('/api/predict', predictRouter);
app.use('/api/registrations', regsRouter);

// Error handler
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: err.message || 'Server error' });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
